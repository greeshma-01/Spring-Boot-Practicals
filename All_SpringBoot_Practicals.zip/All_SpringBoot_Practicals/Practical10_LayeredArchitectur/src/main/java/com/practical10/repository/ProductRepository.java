package com.practical10.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical10.entity.Product;
public interface ProductRepository extends JpaRepository<Product,Integer> {}
