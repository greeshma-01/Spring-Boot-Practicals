package com.practical10.entity;
import jakarta.persistence.*;
@Entity
public class Product {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private int id;
 private String productName;
 private double price;
 private String category;
 private int quantity;
 public Product(){}
 public int getId(){return id;} public void setId(int v){id=v;}
 public String getProductName(){return productName;} public void setProductName(String v){productName=v;}
 public double getPrice(){return price;} public void setPrice(double v){price=v;}
 public String getCategory(){return category;} public void setCategory(String v){category=v;}
 public int getQuantity(){return quantity;} public void setQuantity(int v){quantity=v;}
}
