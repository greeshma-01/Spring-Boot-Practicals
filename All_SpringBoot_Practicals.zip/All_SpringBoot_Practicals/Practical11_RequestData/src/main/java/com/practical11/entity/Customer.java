package com.practical11.entity;
import jakarta.persistence.*;
@Entity
public class Customer {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private int id;
 private String name;
 private String city;
 private int age;
 public Customer(){}
 public int getId(){return id;} public void setId(int v){id=v;}
 public String getName(){return name;} public void setName(String v){name=v;}
 public String getCity(){return city;} public void setCity(String v){city=v;}
 public int getAge(){return age;} public void setAge(int v){age=v;}
}
