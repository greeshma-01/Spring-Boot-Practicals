package com.practical13.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical13.entity.Customer;
public interface CustomerRepository extends JpaRepository<Customer,Integer> {}
