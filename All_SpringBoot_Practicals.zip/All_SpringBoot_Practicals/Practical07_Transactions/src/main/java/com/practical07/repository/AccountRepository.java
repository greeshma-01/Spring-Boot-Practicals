package com.practical07.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical07.entity.Account;
public interface AccountRepository extends JpaRepository<Account,Integer> {}
