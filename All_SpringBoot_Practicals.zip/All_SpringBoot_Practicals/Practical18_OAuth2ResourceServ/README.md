# Practical 18 - OAuth2 Resource Server with JWT
This practical follows the assignment's JWT resource-server configuration. A real issuer is required for JWT validation. Add `spring.security.oauth2.resourceserver.jwt.issuer-uri=...` in `application.properties` before testing protected endpoints.
