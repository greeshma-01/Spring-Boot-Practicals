package com.practical01.entity;
import jakarta.persistence.*;
@Entity
public class Employee {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private int empId;
 private String empName, department; private double salary;
 public Employee(){} public int getEmpId(){return empId;} public void setEmpId(int v){empId=v;} public String getEmpName(){return empName;} public void setEmpName(String v){empName=v;} public String getDepartment(){return department;} public void setDepartment(String v){department=v;} public double getSalary(){return salary;} public void setSalary(double v){salary=v;}
}