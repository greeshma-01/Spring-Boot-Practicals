package com.practical01.repository;
import org.springframework.data.repository.CrudRepository; import com.practical01.entity.Employee;
public interface EmployeeRepository extends CrudRepository<Employee,Integer> {}