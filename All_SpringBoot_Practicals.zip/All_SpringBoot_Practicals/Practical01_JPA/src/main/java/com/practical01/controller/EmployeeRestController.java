package com.practical01.controller;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import org.springframework.beans.factory.annotation.Autowired; import com.practical01.entity.Employee; import com.practical01.repository.EmployeeRepository;
@RestController @RequestMapping("/api/employees") public class EmployeeRestController { @Autowired EmployeeRepository repo;
@PostMapping public ResponseEntity<Employee> save(@RequestBody Employee e){return ResponseEntity.status(201).body(repo.save(e));}
@GetMapping public Iterable<Employee> all(){return repo.findAll();}
@GetMapping("/{id}") public ResponseEntity<Employee> one(@PathVariable int id){return repo.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());}
@PutMapping("/{id}") public ResponseEntity<Employee> update(@PathVariable int id,@RequestBody Employee x){return repo.findById(id).map(e->{e.setEmpName(x.getEmpName());e.setDepartment(x.getDepartment());e.setSalary(x.getSalary());return ResponseEntity.ok(repo.save(e));}).orElse(ResponseEntity.notFound().build());}
@DeleteMapping("/{id}") public ResponseEntity<Void> delete(@PathVariable int id){if(!repo.existsById(id))return ResponseEntity.notFound().build();repo.deleteById(id);return ResponseEntity.noContent().build();}}
