# Practical 01 - Introduction to JPA – Entity Class and Persisting a Single Entity

Use MySQL database `practical01` (created automatically when possible). Port: 8083.

Postman: POST/GET/GET by id/PUT/DELETE `http://localhost:8083/api/employees`.
POST JSON: `{"empName":"Rahul","department":"IT","salary":35000}`.
