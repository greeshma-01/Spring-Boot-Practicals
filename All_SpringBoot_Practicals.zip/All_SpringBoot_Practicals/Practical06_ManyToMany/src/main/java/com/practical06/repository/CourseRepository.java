package com.practical06.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical06.entity.Course;
public interface CourseRepository extends JpaRepository<Course,Integer> {}
