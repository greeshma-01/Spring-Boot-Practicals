package com.practical06.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical06.entity.Student;
public interface StudentRepository extends JpaRepository<Student,Integer> {}
