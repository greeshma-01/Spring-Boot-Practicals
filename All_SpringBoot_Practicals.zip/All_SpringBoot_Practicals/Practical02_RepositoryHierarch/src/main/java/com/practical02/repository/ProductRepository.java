package com.practical02.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical02.entity.Product;
public interface ProductRepository extends JpaRepository<Product,Integer> {}
