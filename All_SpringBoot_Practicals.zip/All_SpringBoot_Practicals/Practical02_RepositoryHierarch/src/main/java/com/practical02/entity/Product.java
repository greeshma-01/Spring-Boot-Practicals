package com.practical02.entity;
import jakarta.persistence.*;
@Entity
public class Product {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private int id;
 private String name;
 private double price;
 public Product(){}
 public int getId(){return id;} public void setId(int v){id=v;}
 public String getName(){return name;} public void setName(String v){name=v;}
 public double getPrice(){return price;} public void setPrice(double v){price=v;}
}
