package com.practical08.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical08.entity.Product;
public interface ProductRepository extends JpaRepository<Product,Integer> {}
