package com.practical03.entity;
import jakarta.persistence.*;
@Entity
public class Employee {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private int id;
 private String empName;
 private String department;
 private double salary;
 public Employee(){}
 public int getId(){return id;} public void setId(int v){id=v;}
 public String getEmpName(){return empName;} public void setEmpName(String v){empName=v;}
 public String getDepartment(){return department;} public void setDepartment(String v){department=v;}
 public double getSalary(){return salary;} public void setSalary(double v){salary=v;}
}
