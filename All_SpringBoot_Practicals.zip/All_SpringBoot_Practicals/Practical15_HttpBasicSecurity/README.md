# Practical 15 - HttpBasicSecurity

Open this folder in STS as an Existing Maven Project.

1. Edit `src/main/resources/application.properties` and set your MySQL root password.
2. Right-click `Application.java` -> Run As -> Spring Boot App.
3. This project uses port **8097**.
4. Test the endpoints shown in this README with Postman.

This project follows the supplied Spring Boot practical assignment terminology and structure.
