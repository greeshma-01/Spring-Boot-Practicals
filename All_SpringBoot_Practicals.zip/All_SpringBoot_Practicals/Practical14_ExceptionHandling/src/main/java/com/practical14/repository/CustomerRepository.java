package com.practical14.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical14.entity.Customer;
public interface CustomerRepository extends JpaRepository<Customer,Integer> {}
