package com.practical14.entity;
import jakarta.persistence.*;
@Entity
public class Customer {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) private int id;
 private String name;
 private String email;
 public Customer(){}
 public int getId(){return id;} public void setId(int v){id=v;}
 public String getName(){return name;} public void setName(String v){name=v;}
 public String getEmail(){return email;} public void setEmail(String v){email=v;}
}
