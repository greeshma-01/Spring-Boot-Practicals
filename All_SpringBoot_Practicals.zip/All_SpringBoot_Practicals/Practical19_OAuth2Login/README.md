# Practical 19 - OAuth2 Login with Google/GitHub
Fill the OAuth2 provider client-id/client-secret and scopes in `application.properties`. Browser login URL after configuration: `http://localhost:8101/oauth2/authorization/google`.
