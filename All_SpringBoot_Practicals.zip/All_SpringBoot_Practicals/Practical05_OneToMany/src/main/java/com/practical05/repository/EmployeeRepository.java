package com.practical05.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical05.entity.Employee;
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {}
