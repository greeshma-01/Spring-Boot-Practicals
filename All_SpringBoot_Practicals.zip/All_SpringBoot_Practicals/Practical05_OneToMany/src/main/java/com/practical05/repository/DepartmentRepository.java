package com.practical05.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical05.entity.Department;
public interface DepartmentRepository extends JpaRepository<Department,Integer> {}
