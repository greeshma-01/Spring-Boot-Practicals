# Advance Java Programming (Spring Boot) - 20 Practicals

This ZIP contains 20 separate Maven Spring Boot projects based on the supplied practical assignment.

## STS import
1. Extract this ZIP.
2. In STS: File -> Import -> Maven -> Existing Maven Projects.
3. Select the individual PracticalXX folder you want to run.
4. Finish, wait for Maven dependencies, edit `application.properties` with your MySQL password where applicable.
5. Right-click `Application.java` -> Run As -> Spring Boot App.

Each project has its own port to avoid conflicts when testing multiple projects.

## Practical list
01 JPA Entity and CRUD
02 Repository Hierarchy
03 Custom Query Methods
04 One-to-One Mapping
05 One-to-Many / Many-to-One
06 Many-to-Many
07 Transaction Management
08 Pagination and Sorting
09 RESTful Microservice
10 Layered Architecture
11 Request Data Handling
12 DTO Pattern
13 Bean Validation
14 Global Exception Handling
15 HTTP Basic Authentication
16 Registration and BCrypt
17 RBAC
18 OAuth2 Resource Server with JWT
19 OAuth2 Login
20 CORS for Secured REST APIs

Practical 18 and 19 require external OAuth2 provider configuration for their secured flows; the projects include the assignment configuration examples as comments so the projects can be imported without inventing credentials.
