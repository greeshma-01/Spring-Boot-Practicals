package com.practical12.repository;
import org.springframework.data.jpa.repository.JpaRepository; import com.practical12.entity.Employee;
public interface EmployeeRepository extends JpaRepository<Employee,Integer> {}
